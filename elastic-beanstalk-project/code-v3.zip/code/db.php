<?php


/**
 * Include the aws php sdk
 * Follow the below instructions for deep dive
 * https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/getting-started_installation.html
 */
require 'vendor/aws-autoloader.php';

/**
 * Import SecretsManagerClient and AwsException to be used
 */
use Aws\SecretsManager\SecretsManagerClient;
use Aws\Exception\AwsException;

/**
 * Create a SecretsManagerClient object
 */
$client = new SecretsManagerClient([
    'region' => 'us-east-1',
    'version' => 'latest',
]);


/**
 * Get the Secret value from AWS Secret Manager
 * Note: Ensure proper IAM role is attached to ECS Task
 */
$result = $client->getSecretValue([
    'SecretId' => "your-secret-id-goes-here",
]);


/**
 * result contains a few key-value about that secret.
 * The key named SecretString has the username and password encoded as a plain json string
 * Decode the json using json_decode function to get username and password
 */
$myJSON = json_decode($result['SecretString']);

define('DB_SERVER', getenv('DB_SERVER'));

define('DB_USERNAME', $myJSON->username);

define('DB_PASSWORD', $myJSON->password);

define('DB_DATABASE', getenv('DB_DATABASE'));

/* Connect to MySQL and select the database. */
$connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);

if (mysqli_connect_errno()) {
echo json_encode(array('message'=>"Failed to connect to MySQL: " . mysqli_connect_error(),'status'=>'error'));die();
}

$database = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
// $database = mysqli_select_db($connection, DB_DATABASE);


/* Add an Contents to the table. */
function addContest($data) {


  global $database;
   $n = mysqli_real_escape_string($database, $data['name']);
   $e = mysqli_real_escape_string($database, $data['email']);
   $r = mysqli_real_escape_string($database, $data['recipe_name']);
   $i = mysqli_real_escape_string($database, $data['ingredients']); 
   $m = mysqli_real_escape_string($database, $data['method']);
   $re = mysqli_real_escape_string($database, $data['region']);
   $query = "INSERT INTO CONTEST (name, email, recipe_name, ingredients, method, region) VALUES ('$n', '$e', '$r', '$i', '$m', '$re');";
   if(!mysqli_query($database, $query)) {
      echo json_encode(array('message'=>'Error on submit data','status'=>'error', 'sql_error'=>mysqli_error($database))); 
      die();
    }
    else {
      echo json_encode(array('message'=>'Thank you for participation!','status'=>'success'));
      die();
    }
}

/* Check whether the table exists and, if not, create it. */
function verifyContestTable() {
  global $database;
  $table = 'CONTEST';  
  if(!isTableExists($table))
  {
     $query = "CREATE TABLE $table (id int(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50), email VARCHAR(50), recipe_name VARCHAR(100), ingredients TEXT, method TEXT,region VARCHAR(50),  created timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP);";
     if(!mysqli_query($database, $query))  { 
         echo json_encode(array('message'=>' Error on create table!','status'=>'error', 'sql_error'=>mysqli_error($database))); 
         die();
      }
  }
}

/* Check for the existence of a table. */
function isTableExists($tableName) {
  global $connection;
  $t = mysqli_real_escape_string($connection, $tableName);
  $d = mysqli_real_escape_string($connection, DB_DATABASE);

  $checktable = mysqli_query($connection,
      "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_NAME = '$t' AND TABLE_SCHEMA = '$d'");

  if(mysqli_num_rows($checktable) > 0) return true;

  return false;
}

function getContest(){
  global $database;
  $data = array();
  $q = "SELECT * FROM CONTEST ";
  if ($result = mysqli_query($database, $q)) {
    /* fetch associative array */
    while ($row = mysqli_fetch_assoc($result)) {
      $data[] = $row;
    }
    /* free result set */
    mysqli_free_result($result);
  }
  return $data;
}