import random

def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    user = event.get("userInput", {}) or {}
    roast = (user.get("roast") or user.get("choice") or "").upper()  # UI may send "roast" or "choice"

    if roast not in ("LIGHT", "MEDIUM", "DARK"):
        session["step"] = "ROAST_PROMPT"
        return {
            "session": session,
            "prompt": "Invalid roast. Choose LIGHT, MEDIUM, or DARK."
        }

    session["roast"] = roast.title()

    if session.get("bean") == "Arabica" and session["roast"] == "Light":
        outcome = {"result": "WIN", "message": "Silky Arabica latte — perfection! ☕✨"}
    elif session.get("bean") == "Robusta" and session["roast"] == "Dark":
        outcome = {"result": "WIN", "message": "Punchy Robusta espresso — boom! 💥☕"}
    elif session.get("bean") == "Liberica" and session["roast"] == "Medium":
        outcome = {"result": "WIN", "message": "Rich Liberican brew — just right! ☕"}
    else:
        # Multiple fun lose messages
        lose_messages = [
            "Over-extracted disaster… try again 😬",
            "The coffee gods are displeased… ☕💀",
            "Yikes! That roast was a catastrophe! 🔥☕",
            "Your cup is a sad puddle of regret… 😢☕",
            "You should just go back to drining tea… 🍵🚫☕",
            "Oops! Coffee chaos unleashed… 😵‍💫☕"
        ]
        outcome = {"result": "LOSE", "message": random.choice(lose_messages)}

    session["done"] = True
    return {
        "session": session,
        "outcome": outcome
    }