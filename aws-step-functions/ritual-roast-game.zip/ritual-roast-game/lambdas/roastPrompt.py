def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    user = event.get("userInput", {}) or {}
    choice = (user.get("choice") or "").upper()

    # Validate coffee bean choice
    if choice not in ("ARABICA", "ROBUSTA", "LIBERICA"):
        session["step"] = "ROAST_PROMPT"
        return {
            "session": session,
            "prompt": "Invalid bean. Choose ARABICA, ROBUSTA, or LIBERICA."
        }

    # Map choice to proper display name
    bean_map = {
        "ARABICA": "Arabica",
        "ROBUSTA": "Robusta",
        "LIBERICA": "Liberica"
    }
    session["bean"] = bean_map[choice]
    session["step"] = "BREW_COFFEE"
    return {
        "session": session,
        "prompt": f"{session['bean']} selected. Roast: LIGHT, MEDIUM, or DARK?"
    }
