def lambda_handler(event, context):
    session = event.get("session", {}) or {}
    session["step"] = "ROAST_PROMPT"
    session["done"] = False
    return {
        "session": session,
        "prompt": "Choose your beans: ARABICA, ROBUSTA, or LIBERICA?"
    }
