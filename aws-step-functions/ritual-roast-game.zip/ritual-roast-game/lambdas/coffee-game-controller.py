import json
import os
import boto3

SFN_ARN = os.environ["STATE_MACHINE_ARN"]
sfn = boto3.client("stepfunctions")

def lambda_handler(event, context):
    # CORS-friendly wrapper
    try:
        if event.get("httpMethod") == "OPTIONS":
            return _resp(200, {})

        body = json.loads(event.get("body") or "{}")
        session = body.get("session") or {"step": "START"}
        userInput = body.get("userInput") or {}

        input_obj = {"session": session, "userInput": userInput}

        exec_resp = sfn.start_sync_execution(
            stateMachineArn=SFN_ARN,
            input=json.dumps(input_obj)
        )

        # The output of an Express sync execution is in exec_resp["output"]
        output = json.loads(exec_resp.get("output") or "{}")

        return _resp(200, output)

    except Exception as e:
        return _resp(500, {"error": str(e)})

def _resp(status, body):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST,OPTIONS"
        },
        "body": json.dumps(body)
    }
